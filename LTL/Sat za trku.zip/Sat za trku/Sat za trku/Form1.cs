﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.VisualBasic.ApplicationServices;

namespace Sat_za_trku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<trkac> trkaci = new List<trkac>();
        TimeSpan stopirajuce;
        DateTime start;
        int upisanih = 0;
        int brojacListeBroj = 0;

        public void ucitaj()
        { 
            try
            {
                StreamReader sr = new StreamReader("trkaci.txt");
                string linija;
                while ((linija = sr.ReadLine()) != null)
                {
                    string[] temp = linija.Split('|');
                    bool p = true;
                    if (temp[3] == "M")
                    {
                        p = true;
                    }
                    else if (temp[3] == "Z")
                    {
                        p = false;
                    }
                    else
                    {
                        break;
                    }

                    bool u = true;
                    if (temp[4] == "DA")
                    {
                        u = true;
                        upisanih++;
                    }
                    else if (temp[4] == "NE")
                    {
                        u = false;
                    }
                    else
                    {
                        break;
                    }

                    TimeSpan v = new TimeSpan(0, 0, 0);
                    if (temp[5] == " ")
                    {
                        v = TimeSpan.Zero;
                    }else
                    {
                        v = TimeSpan.Parse(temp[5]);
                    }

                    trkac novi = new trkac(temp[0], temp[1], temp[2], p, u, v);
                    trkaci.Add(novi); 
                }
                sr.Close();

                StreamReader sr1 = new StreamReader("pocetak.txt");
                string lajna = sr1.ReadLine();
                if(lajna != "NE")
                {
                    bt_pokreni.Enabled = false;
                    start = DateTime.Parse(lajna); 
                }else
                {
                    bt_pokreni.Enabled = true;
                }
                sr1.Close();
            }
            catch (Exception e)
            {
                
            }
        }

        public void upisi(int i)
        {
            try
            {
                StreamWriter sw = new StreamWriter("lista.txt", true);
                sw.WriteLine(trkaci[i].baza() + trkaci[i].Vreme.ToString());
                sw.Close();
                TimeSpan ve = trkaci[i].Vreme;
                string formatiran = ve.Minutes + ":" + ve.Seconds + "." + ve.Milliseconds;
                int m = list_rezutati.Items.Count + 1;
                list_rezutati.Items.Add(m.ToString() + ". " + trkaci[i].Ime + " " + trkaci[i].Prezime + " - " + formatiran);

                if (trkaci[i].Pol)
                {
                    StreamWriter sw1 = new StreamWriter("muskarci.txt", true);
                    sw1.WriteLine(trkaci[i].baza() + trkaci[i].Vreme.ToString());
                    sw1.Close();
                }
                else
                {
                    StreamWriter sw2 = new StreamWriter("zene.txt", true);
                    sw2.WriteLine(trkaci[i].baza() + trkaci[i].Vreme.ToString());
                    sw2.Close();
                }
                upisanih++;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        public void menacLinije(int line_to_edit)
        {
            string[] arrLine = File.ReadAllLines("trkaci.txt");
            string stari = arrLine[line_to_edit - 1];
            int mesto = stari.IndexOf("|NE");
            stari = stari.Substring(0, mesto)+ "|DA|" + (trkaci[line_to_edit - 1].Vreme).ToString() + "|";
            arrLine[line_to_edit - 1] = stari;
            File.WriteAllLines("trkaci.txt", arrLine);
        }

        public void rifres()
        {
            list_trkaci.Items.Clear();
            for(int i = 0; i<trkaci.Count(); i++)
            {
                list_trkaci.Items.Add(trkaci[i]);
            }
            list_Broj.Items.Clear();
            brojacListeBroj = 0;
            tb_Vreme.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ucitaj();
            list_trkaci.Items.Clear();
            for (int i = 0; i < trkaci.Count(); i++)
            {
                list_trkaci.Items.Add(trkaci[i]);
            }
        }

        private void bt_Stopiraj_Click(object sender, EventArgs e)
        {
            stopirajuce = DateTime.Now - start;
            tb_Vreme.Text = stopirajuce.ToString();
            list_Vremena.Items.Add(stopirajuce);
        }

        private void bt_pokreni_Click(object sender, EventArgs e)
        {
            start = DateTime.Now;
            bt_pokreni.Enabled = false;
            StreamWriter sw1 = new StreamWriter("pocetak.txt");
            sw1.WriteLine(start.ToString());
            sw1.Close();
        }

        private void btZapisi_Click(object sender, EventArgs e)
        {
            if (tb_Broj.Text != "")
            {
                int taj = int.Parse(tb_Broj.Text) - 1;
                if (trkaci[taj].Upisan == false)
                {
                    trkaci[taj].cilj(DateTime.Now - start);
                    list_Broj.Items.Add(trkaci[taj]);
                    tb_Broj.Text = "";
                    brojacListeBroj++;
                }
                else
                {
                    MessageBox.Show("Već ste uneli vreme ovog takmicara");
                    tb_Broj.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Niste uneli broj");
            }
        }

        private void bt_Sačuvaj_Click(object sender, EventArgs e)
        {
            for(int i=0; i<brojacListeBroj; i++)
            {
                string ajtem = list_Broj.Items[i].ToString();
                int x = ajtem.IndexOf(" ");
                int broj = int.Parse(ajtem.Substring(0, x)) - 1;
                upisi(broj);
                trkaci[broj].Upisan = true;
                menacLinije(broj+1);
            }
            rifres();
        }

        private void tb_Broj_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (tb_Broj.Text != "")
                {
                    int taj = int.Parse(tb_Broj.Text) - 1;
                    if (trkaci[taj].Upisan == false)
                    {
                        trkaci[taj].cilj(DateTime.Now - start);
                        list_Broj.Items.Add(trkaci[taj]);
                        tb_Broj.Text = "";
                        brojacListeBroj++;
                    }else
                    {
                        MessageBox.Show("Već ste uneli vreme ovog takmicara");
                        tb_Broj.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Niste uneli broj");
                }
            }
        }

        private void bt_Spoji_Click(object sender, EventArgs e)
        {
            try
            {
                TimeSpan vremeIzListe = (TimeSpan)list_Vremena.SelectedItem;
                trkac gospodindja = (trkac)list_trkaci.SelectedItem;

                int mesto = int.Parse(gospodindja.Broj) - 1;
                if (trkaci[mesto].Upisan == false)
                {
                    trkaci[mesto].cilj(vremeIzListe);

                    upisi(mesto);
                    trkaci[mesto].Upisan = true;
                    menacLinije(mesto + 1);
                    rifres();
                    list_Vremena.Items.Remove(list_Vremena.SelectedItem);
                }else
                {
                    MessageBox.Show("Već ste uneli vreme ovog takmicara");
                }
            }catch
            {
                MessageBox.Show("Niste pravilno izabrali podatke");
            }
        }

        private void bt_IzbrisiBroj_Click(object sender, EventArgs e)
        {
            try
            {
                list_Broj.Items.Remove(list_Broj.SelectedItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void bt_IzbrisiVreme_Click(object sender, EventArgs e)
        {
            try
            {
                list_Vremena.Items.Remove(list_Vremena.SelectedItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void bt_IzbrisiSveBroj_Click(object sender, EventArgs e)
        {
            list_Broj.Items.Clear();
            brojacListeBroj = 0;
        }

        private void bt_IzbrisiSveVreme_Click(object sender, EventArgs e)
        {
            list_Vremena.Items.Clear();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            list_Broj.ClearSelected();
            list_trkaci.ClearSelected();
            list_Vremena.ClearSelected();
            list_rezutati.ClearSelected();
            list_muskarciZene.ClearSelected();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Size = new System.Drawing.Size(1139, 707);
            this.MaximumSize = new System.Drawing.Size(1139, 707);
            this.MinimumSize = new System.Drawing.Size(1139, 707);
            list_rezutati.Items.Clear();
            try
            {
                StreamReader srlista = new StreamReader("lista.txt");
                string linija;
                list_muskarciZene.Items.Clear();
                int m = 1;
                while ((linija = srlista.ReadLine()) != null)
                {
                    string[] temp = linija.Split("|");
                    TimeSpan ve = TimeSpan.Parse(temp[3]);
                    string formatiran = "";
                    if(ve.Hours > 0)
                    {
                        formatiran = ve.Hours + ":";
                    }
                    formatiran += ve.Minutes + ":" + ve.Seconds + "." + ve.Milliseconds;
                    list_rezutati.Items.Add(m.ToString() + ". " + temp[1] + " " + temp[2] + " - " + formatiran);
                    m++;
                }
                srlista.Close();
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Size = new System.Drawing.Size(848, 707);
            this.MaximumSize = new System.Drawing.Size(848, 707);
            this.MinimumSize = new System.Drawing.Size(848, 707);
        }

        private void bt_zene_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader srzene = new StreamReader("zene.txt");
                string linija;
                list_muskarciZene.Items.Clear();
                int m = 1;
                while ((linija = srzene.ReadLine()) != null)
                {
                    string[] temp = linija.Split("|");
                    TimeSpan ve = TimeSpan.Parse(temp[3]);
                    string formatiran = "";
                    if (ve.Hours > 0)
                    {
                        formatiran = ve.Hours + ":";
                    }
                    formatiran += ve.Minutes + ":" + ve.Seconds + "." + ve.Milliseconds;
                    list_muskarciZene.Items.Add(m.ToString() + ". " + temp[1] + " " + temp[2] + " - " + formatiran);
                    m++;
                }
                srzene.Close();
            }
            catch(Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }

        private void bt_muskarci_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader srmuskarci = new StreamReader("muskarci.txt");
                string linija;
                list_muskarciZene.Items.Clear();
                int m = 1;
                while ((linija = srmuskarci.ReadLine()) != null)
                {
                    string[] temp = linija.Split("|");
                    TimeSpan ve = TimeSpan.Parse(temp[3]);
                    string formatiran = "";
                    if (ve.Hours > 0)
                    {
                        formatiran = ve.Hours + ":";
                    }
                    formatiran += ve.Minutes + ":" + ve.Seconds + "." + ve.Milliseconds;
                    list_muskarciZene.Items.Add(m.ToString() + ". " + temp[1] + " " + temp[2] + " - " + formatiran);
                    m++;
                }
                srmuskarci.Close();
            }
            catch (Exception exe)
            {
                MessageBox.Show(exe.Message);
            }
        }

        private void dodavanje_Click(object sender, EventArgs e)
        {
            Doda_jNovog myForm = new Doda_jNovog(this);
            myForm.ShowDialog();
        }

        public int vratiN()
        {
            ucitaj();
            return trkaci.Count();
        }

        public void dodajNovogTrkaca(trkac t)
        {
            trkaci.Add(t);
        }
    }
}