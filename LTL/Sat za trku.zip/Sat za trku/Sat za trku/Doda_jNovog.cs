﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sat_za_trku
{
    public partial class Doda_jNovog : Form
    {
        private Form1 _forma;
        public Doda_jNovog(Form1 forma)
        {
            InitializeComponent();
            _forma = forma;
        }

        private void Doda_jNovog_Load(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            int x = f1.vratiN() + 1;
            tb_broooj.Text = x.ToString();
        }

        private void bt_dodjNovog_Click(object sender, EventArgs e)
        {
            try
            {
                if(tb_Ime.Text != "" && tb_Prezime.Text != "" && cb_Pol.Text != "")
                {
                    bool pol = true;
                    string mz = " ";
                    if (cb_Pol.Text == "Muško")
                    {
                        pol = true;
                        mz = "M";
                    }
                    else if (cb_Pol.Text == "Žensko")
                    {
                        pol = false;
                        mz = "Z";
                    }
                    
                    StreamWriter sw = new StreamWriter("trkaci.txt", true);
                    sw.WriteLine(tb_broooj.Text + "|" + tb_Ime.Text + "|" + tb_Prezime.Text + "|" + mz + "|NE| |");
                    sw.Close();
                    trkac t = new trkac(tb_broooj.Text, tb_Ime.Text, tb_Prezime.Text, pol, false, TimeSpan.Zero);
                    _forma.dodajNovogTrkaca(t);
                    _forma.rifres();
                    this.Close();
                }else
                {
                    MessageBox.Show("Upisite sve vrednosti");
                }
            }catch
            {
                MessageBox.Show("Upisite sve vrednosti pravilno");
            }
        }
    }
}
