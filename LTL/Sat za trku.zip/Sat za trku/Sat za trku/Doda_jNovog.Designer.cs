﻿namespace Sat_za_trku
{
    partial class Doda_jNovog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Ime = new System.Windows.Forms.TextBox();
            this.tb_Prezime = new System.Windows.Forms.TextBox();
            this.lbBroj = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_broooj = new System.Windows.Forms.TextBox();
            this.bt_dodjNovog = new System.Windows.Forms.Button();
            this.cb_Pol = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // tb_Ime
            // 
            this.tb_Ime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_Ime.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_Ime.Location = new System.Drawing.Point(102, 59);
            this.tb_Ime.Name = "tb_Ime";
            this.tb_Ime.Size = new System.Drawing.Size(181, 30);
            this.tb_Ime.TabIndex = 12;
            // 
            // tb_Prezime
            // 
            this.tb_Prezime.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_Prezime.Location = new System.Drawing.Point(102, 95);
            this.tb_Prezime.Name = "tb_Prezime";
            this.tb_Prezime.Size = new System.Drawing.Size(181, 30);
            this.tb_Prezime.TabIndex = 13;
            // 
            // lbBroj
            // 
            this.lbBroj.AutoSize = true;
            this.lbBroj.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbBroj.Location = new System.Drawing.Point(51, 66);
            this.lbBroj.Name = "lbBroj";
            this.lbBroj.Size = new System.Drawing.Size(45, 23);
            this.lbBroj.TabIndex = 15;
            this.lbBroj.Text = "Ime";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(13, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 23);
            this.label1.TabIndex = 16;
            this.label1.Text = "Prezime";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(57, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 23);
            this.label2.TabIndex = 17;
            this.label2.Text = "Pol";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(48, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 23);
            this.label3.TabIndex = 18;
            this.label3.Text = "Broj";
            // 
            // tb_broooj
            // 
            this.tb_broooj.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tb_broooj.Enabled = false;
            this.tb_broooj.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_broooj.Location = new System.Drawing.Point(102, 23);
            this.tb_broooj.Name = "tb_broooj";
            this.tb_broooj.Size = new System.Drawing.Size(181, 30);
            this.tb_broooj.TabIndex = 19;
            // 
            // bt_dodjNovog
            // 
            this.bt_dodjNovog.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_dodjNovog.Location = new System.Drawing.Point(65, 195);
            this.bt_dodjNovog.Name = "bt_dodjNovog";
            this.bt_dodjNovog.Size = new System.Drawing.Size(181, 32);
            this.bt_dodjNovog.TabIndex = 20;
            this.bt_dodjNovog.Text = "Dodaj";
            this.bt_dodjNovog.UseVisualStyleBackColor = true;
            this.bt_dodjNovog.Click += new System.EventHandler(this.bt_dodjNovog_Click);
            // 
            // cb_Pol
            // 
            this.cb_Pol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Pol.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cb_Pol.FormattingEnabled = true;
            this.cb_Pol.Items.AddRange(new object[] {
            "Muško",
            "Žensko"});
            this.cb_Pol.Location = new System.Drawing.Point(102, 131);
            this.cb_Pol.Name = "cb_Pol";
            this.cb_Pol.Size = new System.Drawing.Size(181, 31);
            this.cb_Pol.TabIndex = 21;
            // 
            // Doda_jNovog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 264);
            this.Controls.Add(this.cb_Pol);
            this.Controls.Add(this.bt_dodjNovog);
            this.Controls.Add(this.tb_broooj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbBroj);
            this.Controls.Add(this.tb_Prezime);
            this.Controls.Add(this.tb_Ime);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(338, 303);
            this.MinimumSize = new System.Drawing.Size(338, 303);
            this.Name = "Doda_jNovog";
            this.Text = "Doda_jNovog";
            this.Load += new System.EventHandler(this.Doda_jNovog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox tb_Ime;
        private TextBox tb_Prezime;
        private Label lbBroj;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox tb_broooj;
        private Button bt_dodjNovog;
        private ComboBox cb_Pol;
    }
}