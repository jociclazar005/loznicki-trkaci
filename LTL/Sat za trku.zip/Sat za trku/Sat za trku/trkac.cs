﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sat_za_trku
{
    public class trkac
    {
        private string broj;
        private string ime;
        private string prezime;
        private TimeSpan vreme;
        private bool pol;
        private bool upisan;

        public trkac(string broj, string ime, string prezime, bool pol, bool upisan, TimeSpan vreme)
        {
            this.broj = broj;
            this.ime = ime;
            this.prezime = prezime;
            this.Pol = pol;
            this.upisan = upisan;
            this.vreme = vreme;
        }

        public TimeSpan Vreme { get => vreme; set => vreme = value; }
        public bool Pol { get => pol; set => pol = value; }
        public bool Upisan { get => upisan; set => upisan = value; }
        public string Broj { get => broj; set => broj = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }

        public void cilj(TimeSpan x)
        {
            Vreme = x;
        }

        public override string ToString()
        {
            string x = broj + " " + ime + " " + prezime;
            if(vreme != TimeSpan.Zero)
            {
                return x + " " + vreme.ToString();
            }else
            {
                return x;
            }
        }

        public string baza()
        { 
            return broj + "|" + ime + "|" + prezime + "|"; 
        }

        public string rodnoIspravno()
        {
            string to = "";
            if (pol)
            {
                to = "Upisan";
            }
            else
            {
                to = "Upisana";
            }
            return to + " " + broj + " " + ime + " " + prezime + " " + vreme;
        }
    }
}
