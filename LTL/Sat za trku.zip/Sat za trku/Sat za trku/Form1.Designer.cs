﻿namespace Sat_za_trku
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.list_trkaci = new System.Windows.Forms.ListBox();
            this.lb_trkaci = new System.Windows.Forms.Label();
            this.bt_Stopiraj = new System.Windows.Forms.Button();
            this.tb_Vreme = new System.Windows.Forms.TextBox();
            this.list_Vremena = new System.Windows.Forms.ListBox();
            this.lb_vremena = new System.Windows.Forms.Label();
            this.bt_pokreni = new System.Windows.Forms.Button();
            this.lbBroj = new System.Windows.Forms.Label();
            this.list_Broj = new System.Windows.Forms.ListBox();
            this.btZapisi = new System.Windows.Forms.Button();
            this.tb_Broj = new System.Windows.Forms.TextBox();
            this.bt_Sačuvaj = new System.Windows.Forms.Button();
            this.bt_Spoji = new System.Windows.Forms.Button();
            this.bt_IzbrisiBroj = new System.Windows.Forms.Button();
            this.bt_IzbrisiVreme = new System.Windows.Forms.Button();
            this.bt_IzbrisiSveVreme = new System.Windows.Forms.Button();
            this.bt_IzbrisiSveBroj = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.list_rezutati = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.list_muskarciZene = new System.Windows.Forms.ListBox();
            this.bt_muskarci = new System.Windows.Forms.Button();
            this.bt_zene = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dodavanje = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // list_trkaci
            // 
            this.list_trkaci.FormattingEnabled = true;
            this.list_trkaci.ItemHeight = 15;
            this.list_trkaci.Location = new System.Drawing.Point(39, 35);
            this.list_trkaci.Name = "list_trkaci";
            this.list_trkaci.Size = new System.Drawing.Size(300, 529);
            this.list_trkaci.TabIndex = 0;
            // 
            // lb_trkaci
            // 
            this.lb_trkaci.AutoSize = true;
            this.lb_trkaci.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_trkaci.Location = new System.Drawing.Point(126, 9);
            this.lb_trkaci.Name = "lb_trkaci";
            this.lb_trkaci.Size = new System.Drawing.Size(117, 23);
            this.lb_trkaci.TabIndex = 1;
            this.lb_trkaci.Text = "Lista trkača";
            // 
            // bt_Stopiraj
            // 
            this.bt_Stopiraj.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_Stopiraj.Location = new System.Drawing.Point(405, 78);
            this.bt_Stopiraj.Name = "bt_Stopiraj";
            this.bt_Stopiraj.Size = new System.Drawing.Size(353, 65);
            this.bt_Stopiraj.TabIndex = 2;
            this.bt_Stopiraj.Text = "Stopiraj";
            this.bt_Stopiraj.UseVisualStyleBackColor = true;
            this.bt_Stopiraj.Click += new System.EventHandler(this.bt_Stopiraj_Click);
            // 
            // tb_Vreme
            // 
            this.tb_Vreme.Enabled = false;
            this.tb_Vreme.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_Vreme.Location = new System.Drawing.Point(489, 149);
            this.tb_Vreme.Name = "tb_Vreme";
            this.tb_Vreme.ReadOnly = true;
            this.tb_Vreme.Size = new System.Drawing.Size(269, 30);
            this.tb_Vreme.TabIndex = 3;
            // 
            // list_Vremena
            // 
            this.list_Vremena.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.list_Vremena.FormattingEnabled = true;
            this.list_Vremena.ItemHeight = 23;
            this.list_Vremena.Location = new System.Drawing.Point(405, 185);
            this.list_Vremena.Name = "list_Vremena";
            this.list_Vremena.Size = new System.Drawing.Size(353, 142);
            this.list_Vremena.TabIndex = 4;
            // 
            // lb_vremena
            // 
            this.lb_vremena.AutoSize = true;
            this.lb_vremena.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_vremena.Location = new System.Drawing.Point(405, 152);
            this.lb_vremena.Name = "lb_vremena";
            this.lb_vremena.Size = new System.Drawing.Size(69, 23);
            this.lb_vremena.TabIndex = 5;
            this.lb_vremena.Text = "Vreme";
            // 
            // bt_pokreni
            // 
            this.bt_pokreni.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bt_pokreni.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_pokreni.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt_pokreni.Location = new System.Drawing.Point(405, 12);
            this.bt_pokreni.Name = "bt_pokreni";
            this.bt_pokreni.Size = new System.Drawing.Size(353, 60);
            this.bt_pokreni.TabIndex = 6;
            this.bt_pokreni.Text = "Pokreni";
            this.bt_pokreni.UseVisualStyleBackColor = false;
            this.bt_pokreni.Click += new System.EventHandler(this.bt_pokreni_Click);
            // 
            // lbBroj
            // 
            this.lbBroj.AutoSize = true;
            this.lbBroj.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbBroj.Location = new System.Drawing.Point(405, 399);
            this.lbBroj.Name = "lbBroj";
            this.lbBroj.Size = new System.Drawing.Size(48, 23);
            this.lbBroj.TabIndex = 7;
            this.lbBroj.Text = "Broj";
            // 
            // list_Broj
            // 
            this.list_Broj.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.list_Broj.FormattingEnabled = true;
            this.list_Broj.ItemHeight = 18;
            this.list_Broj.Location = new System.Drawing.Point(405, 434);
            this.list_Broj.Name = "list_Broj";
            this.list_Broj.Size = new System.Drawing.Size(353, 130);
            this.list_Broj.TabIndex = 8;
            // 
            // btZapisi
            // 
            this.btZapisi.Location = new System.Drawing.Point(646, 399);
            this.btZapisi.Name = "btZapisi";
            this.btZapisi.Size = new System.Drawing.Size(112, 28);
            this.btZapisi.TabIndex = 10;
            this.btZapisi.Text = "Zapiši";
            this.btZapisi.UseVisualStyleBackColor = true;
            this.btZapisi.Click += new System.EventHandler(this.btZapisi_Click);
            // 
            // tb_Broj
            // 
            this.tb_Broj.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_Broj.Location = new System.Drawing.Point(459, 396);
            this.tb_Broj.Name = "tb_Broj";
            this.tb_Broj.Size = new System.Drawing.Size(181, 30);
            this.tb_Broj.TabIndex = 11;
            this.tb_Broj.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_Broj_KeyDown);
            // 
            // bt_Sačuvaj
            // 
            this.bt_Sačuvaj.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_Sačuvaj.Location = new System.Drawing.Point(632, 582);
            this.bt_Sačuvaj.Name = "bt_Sačuvaj";
            this.bt_Sačuvaj.Size = new System.Drawing.Size(126, 65);
            this.bt_Sačuvaj.TabIndex = 12;
            this.bt_Sačuvaj.Text = "Sačuvaj";
            this.bt_Sačuvaj.UseVisualStyleBackColor = true;
            this.bt_Sačuvaj.Click += new System.EventHandler(this.bt_Sačuvaj_Click);
            // 
            // bt_Spoji
            // 
            this.bt_Spoji.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_Spoji.Location = new System.Drawing.Point(39, 582);
            this.bt_Spoji.Name = "bt_Spoji";
            this.bt_Spoji.Size = new System.Drawing.Size(300, 65);
            this.bt_Spoji.TabIndex = 13;
            this.bt_Spoji.Text = "Spoji";
            this.bt_Spoji.UseVisualStyleBackColor = true;
            this.bt_Spoji.Click += new System.EventHandler(this.bt_Spoji_Click);
            // 
            // bt_IzbrisiBroj
            // 
            this.bt_IzbrisiBroj.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_IzbrisiBroj.Location = new System.Drawing.Point(405, 582);
            this.bt_IzbrisiBroj.Name = "bt_IzbrisiBroj";
            this.bt_IzbrisiBroj.Size = new System.Drawing.Size(106, 65);
            this.bt_IzbrisiBroj.TabIndex = 14;
            this.bt_IzbrisiBroj.Text = "Izbriši";
            this.bt_IzbrisiBroj.UseVisualStyleBackColor = true;
            this.bt_IzbrisiBroj.Click += new System.EventHandler(this.bt_IzbrisiBroj_Click);
            // 
            // bt_IzbrisiVreme
            // 
            this.bt_IzbrisiVreme.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_IzbrisiVreme.Location = new System.Drawing.Point(405, 333);
            this.bt_IzbrisiVreme.Name = "bt_IzbrisiVreme";
            this.bt_IzbrisiVreme.Size = new System.Drawing.Size(156, 45);
            this.bt_IzbrisiVreme.TabIndex = 15;
            this.bt_IzbrisiVreme.Text = "Izbriši";
            this.bt_IzbrisiVreme.UseVisualStyleBackColor = true;
            this.bt_IzbrisiVreme.Click += new System.EventHandler(this.bt_IzbrisiVreme_Click);
            // 
            // bt_IzbrisiSveVreme
            // 
            this.bt_IzbrisiSveVreme.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.bt_IzbrisiSveVreme.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_IzbrisiSveVreme.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt_IzbrisiSveVreme.Location = new System.Drawing.Point(578, 333);
            this.bt_IzbrisiSveVreme.Name = "bt_IzbrisiSveVreme";
            this.bt_IzbrisiSveVreme.Size = new System.Drawing.Size(180, 45);
            this.bt_IzbrisiSveVreme.TabIndex = 16;
            this.bt_IzbrisiSveVreme.Text = "Izbriši sve";
            this.bt_IzbrisiSveVreme.UseVisualStyleBackColor = false;
            this.bt_IzbrisiSveVreme.Click += new System.EventHandler(this.bt_IzbrisiSveVreme_Click);
            // 
            // bt_IzbrisiSveBroj
            // 
            this.bt_IzbrisiSveBroj.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.bt_IzbrisiSveBroj.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_IzbrisiSveBroj.Location = new System.Drawing.Point(520, 582);
            this.bt_IzbrisiSveBroj.Name = "bt_IzbrisiSveBroj";
            this.bt_IzbrisiSveBroj.Size = new System.Drawing.Size(106, 65);
            this.bt_IzbrisiSveBroj.TabIndex = 17;
            this.bt_IzbrisiSveBroj.Text = "Izbriši sve";
            this.bt_IzbrisiSveBroj.UseVisualStyleBackColor = false;
            this.bt_IzbrisiSveBroj.Click += new System.EventHandler(this.bt_IzbrisiSveBroj_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(776, 306);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 44);
            this.button1.TabIndex = 18;
            this.button1.Text = "->";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(776, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 23);
            this.label1.TabIndex = 19;
            this.label1.Text = "Liste";
            // 
            // list_rezutati
            // 
            this.list_rezutati.FormattingEnabled = true;
            this.list_rezutati.ItemHeight = 15;
            this.list_rezutati.Location = new System.Drawing.Point(837, 35);
            this.list_rezutati.Name = "list_rezutati";
            this.list_rezutati.Size = new System.Drawing.Size(274, 304);
            this.list_rezutati.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(933, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 23);
            this.label2.TabIndex = 21;
            this.label2.Text = "Ukupno";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(904, 347);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 23);
            this.label3.TabIndex = 23;
            this.label3.Text = "Mukarci / Žene";
            // 
            // list_muskarciZene
            // 
            this.list_muskarciZene.FormattingEnabled = true;
            this.list_muskarciZene.ItemHeight = 15;
            this.list_muskarciZene.Location = new System.Drawing.Point(837, 373);
            this.list_muskarciZene.Name = "list_muskarciZene";
            this.list_muskarciZene.Size = new System.Drawing.Size(274, 244);
            this.list_muskarciZene.TabIndex = 22;
            // 
            // bt_muskarci
            // 
            this.bt_muskarci.Font = new System.Drawing.Font("Century", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_muskarci.Location = new System.Drawing.Point(837, 623);
            this.bt_muskarci.Name = "bt_muskarci";
            this.bt_muskarci.Size = new System.Drawing.Size(132, 37);
            this.bt_muskarci.TabIndex = 24;
            this.bt_muskarci.Text = "Muškarci";
            this.bt_muskarci.UseVisualStyleBackColor = true;
            this.bt_muskarci.Click += new System.EventHandler(this.bt_muskarci_Click);
            // 
            // bt_zene
            // 
            this.bt_zene.Font = new System.Drawing.Font("Century", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bt_zene.Location = new System.Drawing.Point(979, 623);
            this.bt_zene.Name = "bt_zene";
            this.bt_zene.Size = new System.Drawing.Size(132, 37);
            this.bt_zene.TabIndex = 25;
            this.bt_zene.Text = "Žene";
            this.bt_zene.UseVisualStyleBackColor = true;
            this.bt_zene.Click += new System.EventHandler(this.bt_zene_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(776, 356);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 44);
            this.button2.TabIndex = 26;
            this.button2.Text = "<-";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dodavanje
            // 
            this.dodavanje.Location = new System.Drawing.Point(12, 540);
            this.dodavanje.Name = "dodavanje";
            this.dodavanje.Size = new System.Drawing.Size(21, 24);
            this.dodavanje.TabIndex = 27;
            this.dodavanje.Text = "+";
            this.dodavanje.UseVisualStyleBackColor = true;
            this.dodavanje.Click += new System.EventHandler(this.dodavanje_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(832, 668);
            this.Controls.Add(this.dodavanje);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bt_zene);
            this.Controls.Add(this.bt_muskarci);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.list_muskarciZene);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.list_rezutati);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bt_IzbrisiSveBroj);
            this.Controls.Add(this.bt_IzbrisiSveVreme);
            this.Controls.Add(this.bt_IzbrisiVreme);
            this.Controls.Add(this.bt_IzbrisiBroj);
            this.Controls.Add(this.bt_Spoji);
            this.Controls.Add(this.bt_Sačuvaj);
            this.Controls.Add(this.tb_Broj);
            this.Controls.Add(this.btZapisi);
            this.Controls.Add(this.list_Broj);
            this.Controls.Add(this.lbBroj);
            this.Controls.Add(this.bt_pokreni);
            this.Controls.Add(this.lb_vremena);
            this.Controls.Add(this.list_Vremena);
            this.Controls.Add(this.tb_Vreme);
            this.Controls.Add(this.bt_Stopiraj);
            this.Controls.Add(this.lb_trkaci);
            this.Controls.Add(this.list_trkaci);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(848, 707);
            this.MinimumSize = new System.Drawing.Size(848, 707);
            this.Name = "Form1";
            this.Text = "Sat za trkače";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox list_trkaci;
        private Label lb_trkaci;
        private Button bt_Stopiraj;
        private TextBox tb_Vreme;
        private ListBox list_Vremena;
        private Label lb_vremena;
        private Button bt_pokreni;
        private Label lbBroj;
        private ListBox list_Broj;
        private Button btZapisi;
        private TextBox tb_Broj;
        private Button bt_Sačuvaj;
        private Button bt_Spoji;
        private Button bt_IzbrisiBroj;
        private Button bt_IzbrisiVreme;
        private Button bt_IzbrisiSveVreme;
        private Button bt_IzbrisiSveBroj;
        private Button button1;
        private Label label1;
        private ListBox list_rezutati;
        private Label label2;
        private Label label3;
        private ListBox list_muskarciZene;
        private Button bt_muskarci;
        private Button bt_zene;
        private Button button2;
        private Button dodavanje;
    }
}