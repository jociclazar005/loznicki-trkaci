﻿namespace Sabiranje_bodova
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listaOsoba = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listaOsoba
            // 
            this.listaOsoba.FormattingEnabled = true;
            this.listaOsoba.ItemHeight = 15;
            this.listaOsoba.Location = new System.Drawing.Point(47, 23);
            this.listaOsoba.Name = "listaOsoba";
            this.listaOsoba.Size = new System.Drawing.Size(349, 394);
            this.listaOsoba.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listaOsoba);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ListBox listaOsoba;
    }
}