﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sabiranje_bodova
{
    internal class osoba
    {
        private string ime;
        private string prezime;
        private int brojPoena;

        public osoba(string ime, string prezime, int brojPoena)
        {
            this.ime = ime;
            this.prezime = prezime;
            this.brojPoena = brojPoena;
        }

        public override string ToString()
        {
            return ime + " " + prezime + " - " + brojPoena;
        }
    }
}
