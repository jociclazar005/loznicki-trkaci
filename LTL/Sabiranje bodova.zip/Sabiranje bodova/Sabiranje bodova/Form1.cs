using System.Linq.Expressions;

namespace Sabiranje_bodova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<osoba> Osobe = new List<osoba>();

        public void ucitaj()
        {
            try
            {
                StreamReader sr = new StreamReader("osobe.txt");
                string linija;
                while ((linija = sr.ReadLine()) != null)
                {
                    string[] temp = linija.Split('|');
                    osoba novi = new osoba(temp[0], temp[1], int.Parse(temp[2]));
                    Osobe.Add(novi);
                }
                sr.Close();
            }
            catch (Exception e)
            {

            }

            listaOsoba.Items.Clear();
            for(int i=0; i<Osobe.Count(); i++) 
            {
                listaOsoba.Items.Add(Osobe[i].ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ucitaj();
        }
    }
}